package main.java.travelbook.model;

public interface Entity {

}
