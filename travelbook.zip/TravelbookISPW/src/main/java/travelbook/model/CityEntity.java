package main.java.travelbook.model;

public class CityEntity implements Entity {
	private String nameC;
	private String state;
	
	public String getNameC() {
		return this.nameC;
	}
	public void setNameC(String nameC) {
		this.nameC = nameC;
	}
	public String getState() {
		return this.state;
	}
	public void setState(String state) {
		this.state = state;
	}
	
}
