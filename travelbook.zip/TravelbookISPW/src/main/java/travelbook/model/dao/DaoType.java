package main.java.travelbook.model.dao;

public enum DaoType {
	 USER,
	 OTHERUSER,
	 TRAVEL,
	 STEP,
	 CITY,
	 MESSAGE,
	 S_TRAVEL,
	 S_USER,
	 SEARCH_TRAVEL,
	 FACEBOOK
}
