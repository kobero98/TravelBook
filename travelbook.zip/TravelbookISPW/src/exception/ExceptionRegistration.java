package exception;

public class ExceptionRegistration extends LoginPageException{

	private static final long serialVersionUID = 1L;

	public ExceptionRegistration(String errorMessage) {
		super(errorMessage);
	}
	

}
