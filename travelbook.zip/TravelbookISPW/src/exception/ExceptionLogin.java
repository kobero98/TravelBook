package exception;

public class ExceptionLogin extends LoginPageException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public ExceptionLogin(String message)
	{
		super(message);
	}

}